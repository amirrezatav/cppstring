#include<string>
#include <fstream>
using std::string;
using std::ifstream; // read file 
using std::ofstream; // write on file
#include <codecvt>
#include <locale>
using std::string;
using std::wstring;
using std::wstring_convert;
using std::range_error;


#pragma once
ref class FileManagement
{
private:static wstring convert(string input)
{

	try
	{
		wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
		return converter.from_bytes(input);
	}
	catch (range_error& e)
	{
		size_t length = input.length();
		wstring result;
		result.reserve(length);
		for (size_t i = 0; i < length; i++)
		{
			result.push_back(input[i] & 0xFF);
		}
		return result;
	}
}

public : static wstring ReadFile(std::string path, bool isBinary )
	{
		string lines = "";
		// Not binary
		if (!isBinary)
		{
			ifstream read(path, std::ios::in);
			if (read.is_open())
			{
				while (!read.eof())
				{
					string line;
					getline(read, line);
					lines += line + "\n";
				}
				lines = lines.substr(0, lines.length() - 1);
				return convert(lines);
			}
			else
			{
				throw "File Not open !";
			}
		}
		else
		{
			ifstream read(path , std::ios::in | std::ios::binary);			
		}
	}
};

